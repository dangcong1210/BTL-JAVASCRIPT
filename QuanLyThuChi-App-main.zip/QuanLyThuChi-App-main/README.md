<h2 align="center">Xây dựng đồ án Quản Thu Chi Cá Nhân trên nền tảng Android <a href="https://developer.android.com/" name="spring boot" ><img width="48" height="48" src="https://img.icons8.com/color/48/android-os.png" alt="android-os"/></a></h2>

<h3 align="center">Sử dụng ngôn ngữ lập trình Java và các thẻ xây dựng giao diện được tính hợp sẵn trong Android Studio</h3>

# [**UI**](#ui)

- **Đăng nhập**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/d6955dd5-58e5-413d-80a4-d7a2d1e4619c)


- **Đăng ký**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/4fd52725-425b-4299-a548-1a2df36b6cb2)

- **Trang chủ**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/1ca63197-4cbf-450a-9602-e12713fd7705)

- **Quản lý giao dịch**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/0e08ab5c-1b93-4b7b-955c-dce30b7bd26e)

- **Quản lý danh mục chi tiêu**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/9ec38d25-65e9-41a7-99ea-e3cbf20b132a)
![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/db8a8cfa-bb19-4fec-83b9-973259cc0013)

- **Quản lý ngân sách**
  
![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/027b4a59-741b-4b83-a51b-96e34d91a9e0)

- **Quản lý mục tiêu**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/d1fc4b98-1b9c-443e-8ed2-c6e26ed50e4e)

- **Thống kê**

![image](https://github.com/TranHuuTruong2904/QuanLyThuChi-App/assets/83656656/59e5f3fb-a3c9-4987-bf76-c37c1c5251ae)







